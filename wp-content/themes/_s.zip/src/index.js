import "../src/style.css"

//Modules
import MobileMenu from "./modules/navigation"
import Customizer from "./modules/customizer"

//Instantiate new objects using our modules
const mobileMenu = new MobileMenu()
const customizer = new Customizer()