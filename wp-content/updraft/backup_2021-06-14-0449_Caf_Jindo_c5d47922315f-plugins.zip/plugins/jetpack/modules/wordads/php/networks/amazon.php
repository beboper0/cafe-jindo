<?php
/**
 * Amazon Network.
 *
 * @package automattic/jetpack
 */

// stub.
