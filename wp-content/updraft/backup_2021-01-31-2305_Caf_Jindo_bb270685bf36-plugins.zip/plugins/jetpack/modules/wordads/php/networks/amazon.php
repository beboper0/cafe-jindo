<?php
/**
 * Amazon Network.
 *
 * @package Jetpack.
 */

// stub.
