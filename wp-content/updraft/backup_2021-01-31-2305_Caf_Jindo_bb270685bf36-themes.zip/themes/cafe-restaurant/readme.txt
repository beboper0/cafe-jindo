=== Cafe Restaurant ===
Contributors: dithemes
Requires at least: 4.7
Tested up to: 5.4.2
Requires PHP: 5.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cafe Restaurant is a Responsive, SEO friendly, and fast to load WordPress theme. It is specially designed for cafe, bar, food, hotel, restaurant business, and similar websites.

== Description ==

Cafe Restaurant is a Responsive, SEO friendly, and fast to load WordPress theme. It is specially designed for cafe, bar, food, hotel, restaurant business, and similar websites. User does not need any coding skills or to start from scratch by using Cafe Restaurant WordPress theme. It comes with ready-made demo websites in different variations so users can easily and quickly import the demo of the Cafe Restaurant website and start placing their own contents. It comes with 30+ ready-made demo websites and also has a demo website for bar, cafe, hotel, and restaurant. Cafe Restaurant WordPress theme is fully compatible with the WooCommerce plugin so the user can sell their products on the website using the Cafe Restaurant WordPress theme. It also adds additional eCommerce options to customize features of the WooCommerce plugin. Moreover, the Cafe Restaurant WordPress theme adds an additional menu in the footer section above the footer widget so the user can easily add more useful links in the footer. Footer menu also comes with typography options so users can change font family, font size, letter spacing, letter margin, etc. and makes its looks more attractive easily. It also allows the user to add recent posts slider and posts slider base on the selected category so the user can display their posts in the slider instead normal list. Cafe Restaurant theme is a fully responsive theme and fits in all types of devices. It uses the latest version of a responsive framework known as Bootstrap 4. This theme is totally SEO friendly and follows the recommended page structure that will help to rank user website on the search engines. It also includes the structured data so search engines can easily understand about content of each page. You can add FAQ, article, Organization, etc. structure data. Moreover, it allows you to add recipes and review structure data. Restaurant Cafe is a page builder friendly theme. It works with all popular page builder plugin like Elementor, Visual Composer, Site Origin, etc. It also comes with the Full-Width page template so users can display page builder contents without extra spacing. User can find all the color options in the Cafe Restaurant WordPress theme and these color options are totally free. no additional plugin is needed for color options. Moreover, it allows users to design there owns custom colors in the Hexa format. Restaurant Cafe comes with multiple website layouts like Left Sidebar, Right Sidebar, Full Width, Custom Container Width, Boxed layout, etc.

== Frequently Asked Questions ==

= Installation =

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in 'Cafe Restaurant' in the search form and press the 'Enter' key on your keyboard.
3. Click on 'Install' and then 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel and customize the taste.

= Where are theme settings? =

Navigate to Appearance > Customize in your admin panel.

== Changelog ==

= 1.0 =
* First release

== Upgrade Notice ==

= 1.0 =
* First release

== Resources ==
* Di Multipurpose Theme, Copyright 2019 DiThemes
* Di Multipurpose Theme is distributed under the terms of the GNU GPL
* Screenshot Image: https://stocksnap.io/photo/brunch-breakfast-1FN4OKZCTQ, (C) Candace McDaniel, [CC0](https://stocksnap.io/license), 
