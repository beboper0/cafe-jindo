<div class="di-post-categories">
	<p class="categoryurl"><?php the_category( ' • ' ); ?></p>
</div>
