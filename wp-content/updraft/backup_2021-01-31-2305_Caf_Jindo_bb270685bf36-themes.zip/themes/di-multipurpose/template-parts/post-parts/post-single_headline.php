<div class="content-second di-post-title">
	<h1 class="the-title entry-title" itemprop="headline"><?php the_title(); ?></h1>
</div>