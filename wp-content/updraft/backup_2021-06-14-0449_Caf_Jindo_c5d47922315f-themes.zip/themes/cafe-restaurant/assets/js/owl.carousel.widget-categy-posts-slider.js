( function( $ ) {
	$(document).ready(function() {

		$('.di-categy-news-cur').owlCarousel({
			loop:true,
			dots:true,
			nav:false,
			autoplay:true,
			autoplayHoverPause:true,
			items:1,
		});

	});
} )( jQuery );
