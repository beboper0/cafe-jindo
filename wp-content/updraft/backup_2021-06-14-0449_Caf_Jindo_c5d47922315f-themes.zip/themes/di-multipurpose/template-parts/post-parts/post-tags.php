<div class="di-singletags">
	<?php 
	if( has_tag() ) { ?>
		<div class="singletags"><?php the_tags( '', ' ', '' ); ?></div>
	<?php
	}
	?>
</div>